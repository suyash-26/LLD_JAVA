package org.example.BankingSystem.SBI;

import org.example.BankingSystem.Bank;
import org.example.BankingSystem.interfaces.Account;

import java.util.HashMap;
import java.util.Map;

public class SBIBank implements Bank {
    private final Map<String, SBIAccount> accounts = new HashMap<>();

    @Override
    public String addAccount(Account account) {
        if (!(account instanceof SBIAccount sbiAccount)) {
            return "Invalid account type for SBI Bank";
        }
        accounts.put(sbiAccount.getAccountId(), sbiAccount);
        return "Account added";
    }

    @Override
    public String deleteAccount(String accountId) {
        if (accounts.remove(accountId) == null) {
            return "Invalid Account";
        }
        return "Account removed";
    }

    @Override
    public String depositAmount(String accountId, String password, Double amount) {
        SBIAccount account = accounts.get(accountId);
        if (account == null || !account.matchesPassword(password)) {
            return "Invalid Account";
        }
        return account.deposit(amount);
    }

    @Override
    public String withdrawAmount(String accountId, String password, Double amount) {
        SBIAccount account = accounts.get(accountId);
        if (account == null || !account.matchesPassword(password)) {
            return "Invalid Account";
        }
        return account.withdraw(amount);
    }

    @Override
    public String checkBalance(String accountId, String password) {
        SBIAccount account = accounts.get(accountId);
        if (account == null || !account.matchesPassword(password)) {
            return "Invalid Account";
        }
        return "Available Balance: " + account.checkBalance();
    }
}
